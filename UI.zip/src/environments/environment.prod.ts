export const environment = {
  production: true,
  apiUrl : 'http://localhost:9080',
  visaAdminUrl: 'http://localhost:9080/userAdmin',
  loginapiUrl: 'http://localhost:9080/loginservice'
};
