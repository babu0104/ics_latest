import { Injectable } from '@angular/core';
/*import { Name } from '../_models/manual-entry/nameNode';
import { Address } from '../_models/manual-entry/addressNode';
import { FormData } from '../_models/manual-entry/formdataNode';
import { ManualentryList } from '../_models/manual-entry/manualentryListNode';
import { RootObject } from '../_models/manual-entry/rootNode';*/
//import { Name,Address,FormData,ManualentryList,RootObject } from '../interfaces/manualentryform';
import { Name,Address,FormData,ManualentryList,RootObject } from '../_models/manual-entry/manualentry';

@Injectable()
export class ManualEntryService {

    createNameNode(param) 
    {
            let nameobj=new Name();
            let namearray=[];
            nameobj.firstName=param.first;
            nameobj.middleName=param.middle;
            nameobj.lastName=param.last;
            namearray.push(nameobj);
            return namearray;
    }
    createAddressNode(param)
    {
            let addressarray=[];
            let addobj=new Address();
            addobj.primaryaddress1=param.addr1;
            addobj.primaryaddress2=param.addr2;
            addressarray.push(addobj);
            return addressarray;

    }
    createformDataNode(param,getname,getaddress)
    {
            let formarray=[];
            let formdataobj=new FormData();
            formdataobj.name=getname;
            formdataobj.ssn=param.ssnNumber;
            formdataobj.dob=param.bDate;
            formdataobj.address=getaddress;
            formdataobj.city=param.city;
            formdataobj.state=param.state;
            formdataobj.zip=param.zip;
            formdataobj.ip=param.ipaddress;
            formdataobj.phone=param.phonenumber1;
            formdataobj.email=param.email;
            formdataobj.accountNo=param.accno;
            formdataobj.comments=param.comments;
            formarray.push(formdataobj);
            return formarray;
    }
    createManualentryNode(param,getformData)
    {
        let manualentrylistArr=[];
        let manualentryList=new ManualentryList();
        manualentryList.user_id=param.user_id;
        manualentryList.submission_type=param.submission_type;
        manualentryList.formData=getformData;
        manualentrylistArr.push(manualentryList);
        return manualentrylistArr;
    }
    createfinalList(param,getmanualentryList)
    {
        let rootList=new RootObject();
        rootList.status=param.status;
        rootList.message=param.message;
        rootList.manualentryList=getmanualentryList;
        return rootList;
    }

}