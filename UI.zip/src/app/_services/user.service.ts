import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/map';
import * as _ from 'underscore';
import { Client } from '../http-client.service';
import { AuthHttp, AuthConfig, JwtHelper } from 'angular2-jwt';
import { AuthenticationService } from '../_services/index';
import { User } from '../_models/index';
import { Role } from '../_models/Role';
import { environment } from '../../environments/environment';
import { ObjectUtils } from '../../app/util';

@Injectable()
export class Auth_UserService {
    userModel : User;
    roleModel = new Role();
    _jwtHelper : JwtHelper = new JwtHelper();
    private subject = new Subject<boolean>();
    private apilogin: string;
    constructor(
        private http: Http,
        private authenticationService: AuthenticationService,
        private api : Client,
        private util : ObjectUtils,
    ) {
        this.userModel = new User();
        this.apilogin = environment.loginapiUrl;
    }

    validateUser(username , password): Observable< User >{
        let _self = this;
        let encryptUserName = btoa(username);
        let encryptPwd = btoa(password);
        _self.userModel.clear(); //reset the model
        return this.http.post(this.apilogin+'/login', JSON.stringify({ username: username, password: password }))
        // return this.http.post('http://10.28.140.153:8080/loginservice/login', JSON.stringify({ username: username, password: password }))
        .map((response: Response) => {
            let token = response.status == 200 && response.headers.get("authorization");
            if(token)
            {
                this.userModel.authToken = token;
                let decode =  this._jwtHelper.decodeToken(token);
                let date = this._jwtHelper.getTokenExpirationDate(token);
                let isexpired = this._jwtHelper.isTokenExpired(token)
                this.userModel.role = _.isNull(decode.scopes[0]) ? "" : decode.scopes[0].authority;
                this.userModel.isAuthenticated = true;
                this.util.setRoleLable( this.userModel.role );
                this.setLoggedInUserDetails( username, this.userModel.role , this.userModel.authToken, this.userModel.isAuthenticated ); 
                
                return this.userModel;
            }
            else{
                this.userModel.isAuthenticated = false;
                this.userModel.authToken = null; 
                return this.userModel;
            }
    });
  }

  setLoggedInUserDetails = (username, role, token, isAuthenticated) =>{
    let _self = this;
    let encryptedRole = btoa(role);
    localStorage.setItem('currentUser', username );
    localStorage.setItem('role', encryptedRole);    
    localStorage.setItem('authToken', token);
    localStorage.setItem("isAuthenticated", isAuthenticated);
    return true;
  }

  getLoggedInUserDetails = () =>{
      let _self = this;
      let validUserModel = new User(); //new instance for successful logedin user
      validUserModel.clear(); //rest the model
      let decryptedRole = atob(localStorage.getItem('role'));
      validUserModel.userName = localStorage.getItem('currentUser');
      validUserModel.authToken = localStorage.getItem('authToken');
      validUserModel.role = decryptedRole;            
      let value = localStorage.getItem("isAuthenticated");
      if(_.isNull(value))
        validUserModel.isAuthenticated = false;
      else
        validUserModel.isAuthenticated = (value == 'false' ? false : true); //typecast string boolean to actual boolean
      
      return validUserModel;
  }

    fetchPermittedPages(role:string): Observable< Array<any> >{
        return this.http.get('/assets/data/app.urlmap.json')
        .map((res) =>{
            let data=res.json();
            const result = [];
            Object.keys(data).forEach( key => {
                if(data[key].role === role){
                    result.push(data[key]);
                }
            });
            return result;
        }); 
    }
}