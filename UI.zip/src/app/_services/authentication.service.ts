import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import { Router, CanActivate } from '@angular/router';
import { tokenNotExpired, JwtHelper } from 'angular2-jwt';
import { Client } from '../http-client.service'
import * as _ from 'underscore';

import { User } from '../_models/index';
import { Role } from '../_models/Role';



@Injectable()
export class AuthenticationService {
    userModel = new User();
    roleModel = new Role();

    constructor(private http: Http, private api : Client) {
        // set token if saved in local storage       
    }

    getUserDefaultInfo(username: string): Observable<JSON>{
        let userName = _.isUndefined(username) ?  false : username ;
        let headerOption;
        headerOption = this.api.getRequestOptions('application/json');
        return this.http.post('/api/authenticate', username)
                .map((res:Response) => 
                res.json()
            );
    }
    
    loggedIn() {
        // Check if there's an unexpired JWT
        // This searches for an item in localStorage with key == 'id_token'
        //return tokenNotExpired(currentUserToken); ==> refer the actual format of jwt it should have 3 parts
        //debugger;
        let currentUser = localStorage.getItem('currentUser');
        if(currentUser === null || undefined)
            return false;
        else
            return true;
    }
}