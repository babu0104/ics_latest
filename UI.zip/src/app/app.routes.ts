import { Routes, RouterModule } from '@angular/router';

import { MainComponent } from './shared/main/main.component';
import { FaqComponent } from './shared/faq/faq.component';
import { RulesComponent } from './shared/rules/rules.component';
import { LoginComponent } from './shared/login/login.component';
import { HelpComponent } from './shared/help/help.component';
import { ContactComponent } from './shared/contact/contact.component';
import { IcsHomeComponent } from './components/ics-home/ics-home.component';
import { HomePageComponent } from './components/home/home-page.component';
import { ManualEntryComponent } from './components/manual-entry/manual-entry.component';
import { ViewRecordsComponent } from './components/view-records/view-records.component';
import { PreferencesComponent } from './components/preferences/preferences.component';
import { FileUploadComponent } from './components/file-upload/file-upload.component';
import { UserAdminComponent } from './components/user-admin/user-admin.component';
import { ReceiveFilesComponent } from './components/receive-files/receive-files.component';
import { NotFoundComponent } from './shared/not-found/not-found.component';
import { TieredPricingComponent } from './components/tiered-pricing/tiered-pricing.component';
import { AdjustmentComponent } from './components/adjustment/adjustment.component';
//Manual Entry - individual forms
import { ManualEntryApplicationFormComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-application-form/manual-entry-application-form.component';
import { ManualEntryDeclinedApplicationFormComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-declined-application-form/manual-entry-declined-application-form.component';
import { LoadReloadComponent } from './components/manual-entry/manual-entry-submission-type/load-reload/load-reload.component';
import { ManualEntryUnauthorizedUseFormComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-unauthorized-use-form/manual-entry-unauthorized-use-form.component';
import { ManualEntryInquiryFormComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-inquiry-form/manual-entry-inquiry-form.component';
import { ManualEntryDebitInquiryFormComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-debit-inquiry-form/manual-entry-debit-inquiry-form.component';
import { ManualEntryNonBankcardInquiryFormComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-non-bankcard-inquiry-form/manual-entry-non-bankcard-inquiry-form.component';
import { ManualEntryRetroactiveInquiryFormComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-retro-active-inquiry-form/manual-entry-retro-active-inquiry-form.component';
import { ManualEntryDeleteComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-delete/manual-entry-delete.component';
import { ManualEntryResponseComponent } from './components/manual-entry/manual-entry-response/manual-entry-response.component';
import { ReportsComponent } from './components/reports/reports.component';
import { NewUserComponent } from './components/user-admin-createuser/new-user.component';
import { EditUserComponent } from './components/user-admin-edituser/edit-user.component';
import { AuthGuard } from '../app/_guard/index';
import { AuthAnonymousGuard } from '../app/_guard/auth.anonymousguard';
import { LoaderComponent } from './shared/loader/loader.component';

export const routes: Routes = [
  { path: '', component: MainComponent,canActivate: [AuthAnonymousGuard] },
  { path: 'faq', component: FaqComponent },
  { path: 'rules', component: RulesComponent },
  { path: 'help', component: HelpComponent },
  { path: 'contact', component: ContactComponent },
  { path: 'login', component: LoginComponent,canActivate: [AuthAnonymousGuard] }, //,canActivate: [AuthAnonymousGuard]
  { path: 'ics-home', component: IcsHomeComponent, canActivateChild: [AuthGuard],
      children: [
      //{ path: '', redirectTo: 'ics-home', pathMatch: 'full' },
        { path: 'home', component: HomePageComponent},
        { path: 'response', component: ManualEntryResponseComponent },
        { path: 'manual-entry', component: ManualEntryComponent,canActivateChild : [AuthGuard],
          children: [
            { path: '', pathMatch: 'full', redirectTo: 'aa' },
            { path: 'aa', component: ManualEntryApplicationFormComponent,},
            { path: 'aa/:id', component: ManualEntryApplicationFormComponent, },
            { path: 'da', component: ManualEntryDeclinedApplicationFormComponent, },
            { path: 'da/:id', component: ManualEntryDeclinedApplicationFormComponent, },
            { path: 'uf', component: ManualEntryUnauthorizedUseFormComponent, },
            { path: 'uf/:id', component: ManualEntryUnauthorizedUseFormComponent, },
            { path: 'if', component: ManualEntryInquiryFormComponent, },
            { path: 'if/:id', component: ManualEntryInquiryFormComponent, },
            { path: 'di', component: ManualEntryDebitInquiryFormComponent, },
            { path: 'di/:id', component: ManualEntryDebitInquiryFormComponent, },
            { path: 'ni', component: ManualEntryNonBankcardInquiryFormComponent, },
            { path: 'ni/:id', component: ManualEntryNonBankcardInquiryFormComponent, },
            { path: 'ri', component: ManualEntryRetroactiveInquiryFormComponent, },
            { path: 'ri/:id', component: ManualEntryRetroactiveInquiryFormComponent, },
            { path: 'pr', component: LoadReloadComponent, },
            { path: 'pr/:id', component: LoadReloadComponent, },
            { path: 'ad', component: ManualEntryDeleteComponent, },
            { path: 'ad/:id', component: ManualEntryDeleteComponent, },
            
          ]
        },
        { path: 'view-records', component: ViewRecordsComponent},
        { path: 'reports', component: ReportsComponent},
        { path: 'preferences', component: PreferencesComponent},
        { path: 'file-upload', component: FileUploadComponent},
        { path: 'user-admin', component: UserAdminComponent},
        { path: 'receive-files', component: ReceiveFilesComponent},
        { path: 'new-user', component: NewUserComponent},
        { path: 'edit-user', component: EditUserComponent},
        { path: 'tiered-pricing', component: TieredPricingComponent},
        { path: 'adjustment', component: AdjustmentComponent}
      ]
  },
    //Not Found Redirection
  { path: '**', redirectTo: 'not-found'},
  { path: 'not-found', component: NotFoundComponent },
];




export const appRoutingProviders: any[] = [

];
export const routing = RouterModule.forRoot(routes);
