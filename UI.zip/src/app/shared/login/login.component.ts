import { Component, OnInit ,ElementRef,ViewChild, Renderer} from '@angular/core';
import { PlatformLocation } from '@angular/common'
import { Router } from '@angular/router';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { UserLoginService } from '../../services/userLoginService';
import { NgForm } from '@angular/forms';
import { AuthenticationService, Auth_UserService } from '../../_services/index';
import { User } from '../../_models/user';
import { AuthState } from '../../_models/authstate';
import * as _ from 'underscore';
import { Role } from '../../_models/Role';
import { CommonErrorComponent } from '../common-error/common-error.component';
import { ObjectUtils } from '../../util'
import { environment } from '../../../environments/environment';
import { HeaderComponent} from '../../shared/header/header.component';
import { AppComponent } from '../../app.component';
import { config } from '../../config';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  providers: [ObjectUtils, HeaderComponent],
})
export class LoginComponent implements OnInit {
  @ViewChild('myInput') input: ElementRef;
  model = new User();
  authState: AuthState;
  loading = false;
  error = '';
  roleModel = new Role();
  backendErrorStatus: boolean = true;
  userName: any;
  isUserPresent: any;
  loginCancelled: boolean = false;
  private api: string;
  constructor(private http: Http,private router: 
    Router,private userLoginService: UserLoginService, 
    private authenticationService: AuthenticationService, 
    private userService: Auth_UserService, 
    private renderer: Renderer, 
    private location: PlatformLocation,
    private headerComponent : HeaderComponent, 
    private utilObject: ObjectUtils, 
    private App : AppComponent,
    private _config : config) {
      this.utilObject.hideSignInLink();
      this.api = environment.loginapiUrl;
  }


  ngOnInit() {
    let _self = this;
    this.userName = localStorage.getItem('userName');
    if(this.userName)
    {  
      this.renderer.invokeElementMethod(this.input.nativeElement, 'focus');
      let url = this.api +"/getImageOnUserId";
      let headers = new Headers({ 'Content-Type': 'application/json' });
      let options = new RequestOptions({ headers: headers });
      this.http.post(url, JSON.stringify({userId:this.userName}), options)
      .subscribe( data => {
          if(!_.isNull(data)){
            let result = data.json(); 
            if(!_.isUndefined(result.imageName))           
              this.model.secImage = _.isNull(result.imageName) ? this._config.DEFAULTSECIMG : result.imageName;
            if(!_.isUndefined(result.userId))
              this.model.userName = _.isNull(result.userId) ? '': result.userId;
            if(!_.isUndefined(result.secQuestion))
              this.model.secPhrase = _.isNull(result.secQuestion) ? this._config.DEFAULTSECPHRASE : result.secQuestion;
          }
        },
        err => {
          console.log("error received");
        }
      );
    }
    else
      this.router.navigate(['']);
  }

  PreventBack = () => {
    history.forward();
  }

  login = () => {
    let _self = this;
    _self.App.displayloader();
    this.userService.validateUser(this.userName, this.model.password)
      .subscribe(result => {
        if ( result.isAuthenticated == true) {
            document.getElementById("error").setAttribute("style","display:none");
            _self.App.hideloader();   
            _self.router.navigate(['/ics-home/home']);
        } else {
          document.getElementById("error").setAttribute("style","display:block");                    
          _self.App.hideloader();
          _self.router.navigate(['']);
        }
      });
  }

  passwordKeyDown = (event) => {
    if ((!_.isUndefined(event)) && event.keyCode == 13) {
      this.login();
    }
  }

  onCancel = (event) => {
    this.model.userName = '';
    this.utilObject.clearLocalStorage();
    this.router.navigate(['']);
  }

}
