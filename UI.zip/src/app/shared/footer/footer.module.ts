import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FooterComponent } from './footer.component';

@NgModule({
  declarations: [ FooterComponent ],
  exports: [ FooterComponent ],
  imports: [ CommonModule ],
  schemas: [ NO_ERRORS_SCHEMA ]
})
export class FooterModule {}
