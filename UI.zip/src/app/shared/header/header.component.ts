import { Component, OnInit, Injectable } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { User } from '../../_models/index';
import { AuthState } from '../../_models/authstate';
import { AuthenticationService, Auth_UserService } from '../../_services/index';
import { UserLoginService } from '../../services/userLoginService';
import * as _ from 'underscore';
import { ObjectUtils } from '../../util';
import { AfterViewInit } from '@angular/core/src/metadata/lifecycle_hooks';

declare var $: any;
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  providers: [ObjectUtils],
})

@Injectable()
export class HeaderComponent implements AfterViewInit {
  model: User = new User();
  role: any;
  userName: string;
  authState: AuthState;
  userNameIsValid: boolean;
  userData: any;
  isNameEntered: boolean;
  showSignIn: boolean;
  isUserPresent: any;
  error: boolean;

  constructor(
    private router: Router,
    private authenticationService: AuthenticationService,
    private userService: Auth_UserService,
    private userLoginService: UserLoginService,
    private utilObject: ObjectUtils
  ) {
    this.role = this.utilObject.getRoleLabel();
    this.getSuccessfullLoginState();
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.role = this.utilObject.getRoleLabel(); 
      this.userName = localStorage.getItem("userName");      
      let dom1 = document.getElementById("user-role");
      let dom2 = document.getElementById("user-name");
      if(!_.isNull(dom1))
        dom1.innerHTML = "("+ this.role +")";
      if(!_.isNull(dom2))
          dom2.innerText = this.userName;   
    }, 1000);
  }

  getSuccessfullLoginState = () => {
    let currentUserModel = this.userService.getLoggedInUserDetails();
    if (!_.isUndefined(currentUserModel)) {
      this.error = currentUserModel.isAuthenticated;
      this.userName = currentUserModel.userName;
      this.role = this.utilObject.getRoleLabel();    //temp fix
      this.userName = localStorage.getItem("userName");             
    }
  }

  showOverlay = ($event) => {
    document.getElementById('UserName_input').focus();
  }

  onSubmit = (event) => {
    let _self = this;
    let result, obj;
    let userNameVal = this.model.userName;
    let enteredUserName = (userNameVal === undefined || userNameVal.length <= 0) ? false : true;
    if (enteredUserName) {
      localStorage.setItem('userName', userNameVal);
      this.router.navigate(['/login']);
    } else {
      this.model.isUserNamePresent = false;
    }
    this.model.userName = '';
  }

  navToLanding = (event) => {
    if (this.isLoggedIn())
      return false;
    else
      this.router.navigate(['']);
  }

  signOut = (event) => {
    this.utilObject.clearLocalStorage();
    AuthState.isLoggedIn = false;
    this.router.navigate(['']);
  }

  isLoggedIn = (): boolean => {
    let currentUser = localStorage.getItem('currentUser');
    if (_.isNull(currentUser) || _.isUndefined(currentUser))
      this.isUserPresent = false;
    else
      this.isUserPresent = true;
    return this.isUserPresent;
  }

  showSignInForm = (event) => {
    document.getElementById('sigin-link').classList.toggle('sign-form-show');
  }

  onClickedOutside = (e: Event) => {
    document.getElementById('sigin-link').classList.remove('sign-form-show');
  }
}
