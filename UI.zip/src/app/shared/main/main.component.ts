import { Component, OnInit } from '@angular/core';
import { ObjectUtils } from '../../util'

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss'],
  providers: [ObjectUtils],
})
export class MainComponent implements OnInit {

  constructor(private utilObject: ObjectUtils) {
  }

  ngOnInit() {
  }
  ngAfterViewInit() {
    //stuff that doesn't do view changes
    setTimeout(_ =>  this.utilObject.showSignInLink());
  }

}
