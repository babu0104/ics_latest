import { Component, OnInit } from '@angular/core';
import { CommonErrorComponent } from '../../shared/common-error/common-error.component';
import { CalendarModule } from 'primeng/primeng';
import { MessageService } from '../../services/message.service';

@Component({
  moduleId: module.id,
  selector: 'app-manual-entry',
  templateUrl: './manual-entry.component.html',
  styleUrls: ['./manual-entry.component.scss']
})
export class ManualEntryComponent implements OnInit {
  ssnNumber: string;
  message: any;
  constructor(private messageService: MessageService) { 
   this.messageService.getMessage().subscribe(message => { this.message = message; });
  }
  ngOnInit() {
  }


}
