import { Component, OnInit, ElementRef,Directive, forwardRef, Attribute,OnChanges, SimpleChanges,Input } from '@angular/core';
import { NG_VALIDATORS,Validator,Validators,AbstractControl,ValidatorFn } from '@angular/forms';
import { ObjectUtils } from '../../../../util';
import { User } from '../../../../User';
import { Router } from '@angular/router';
import { ManualEntryService } from '../../../../_services/manualentry.service';
import { MessageService } from '../../../../services/message.service';
/*import { Name } from '../../../../_models/manual-entry/nameNode';
import { Address } from '../../../../_models/manual-entry/addressNode';
import { FormData } from '../../../../_models/manual-entry/formdataNode';
import { ManualentryList } from '../../../../_models/manual-entry/manualentryListNode';
import { RootObject } from '../../../../_models/manual-entry/rootNode';*/
import { Name,Address,FormData,ManualentryList,RootObject } from '../../../../_models/manual-entry/manualentry';
declare var $: any;
@Component({
  selector: 'app-manual-entry-application-form',
  templateUrl: './manual-entry-application-form.component.html',
  styleUrls: ['./manual-entry-application-form.component.scss']
})
export class ManualEntryApplicationFormComponent implements OnInit {
  utilObject : ObjectUtils;
  value: Date;
  phonenumber1: string;
  phonenumber2: string;
  resultDate:any;
  targetValue:any;
  first:string;
  user=new User();
  sec_count:number = 0;
  phone_count: number = 0;
  manualentry={};
  user_id:number;
  message: any;
  subscription_type: string;
  //addresses:Address;

  constructor(private elRef:ElementRef, private router: Router,private ManualEntryService:ManualEntryService,private messageService: MessageService) { 
    this.utilObject=new ObjectUtils();

    
  }
  onCancel(event){
		this.router.navigate(['/ics-home/home-page']);
	}
  ngOnInit() {
  }
  onkeyup(event)
  {
    this.utilObject.onFocus(event.target.value,this.elRef.nativeElement,event.keyCode);
  }
  submitted = false;
  data: string;
  onSubmit(data) {
     
     this.buildmanualentry(data);
  }
  buildmanualentry(param:User)
  {
     this.subscription_type="Application";
     param['user_id']=1;
     param['submission_type']=this.subscription_type;
     param['status']=1;
     param['message']="Post manual entry data";
     let getname=this.ManualEntryService.createNameNode(param);
     let getaddress=this.ManualEntryService.createAddressNode(param);
     let getformData=this.ManualEntryService.createformDataNode(param,getname,getaddress)
     let getmanualentryList=this.ManualEntryService.createManualentryNode(param,getformData);
     let finalListObject=this.ManualEntryService.createfinalList(param,getmanualentryList);    
     let finalresult=JSON.stringify(finalListObject);
     console.log(finalresult);   
  }
  postJson(getJson:any)
  {
      console.log(getJson);
  }
  address() {
    this.sec_count = this.sec_count + 1;
    let sec = document.getElementsByClassName('sec-address');
    sec[0].classList.add('show');
    let add_btn = document.getElementsByClassName('add-btn');
    add_btn[0].classList.add('disable');
  }

  phone() {
    this.phone_count = this.phone_count + 1;
    let phone = document.getElementsByClassName('sec-phone');
    phone[this.phone_count - 1].classList.add('show');
    if (this.phone_count === 2) {
      let add = document.getElementsByClassName('phone-btn');
      add[0].classList.add('disable');
    }
  }

}

