import { Component, OnInit, ElementRef,Directive, forwardRef, Attribute,OnChanges, SimpleChanges,Input } from '@angular/core';
import { NG_VALIDATORS,Validator,Validators,AbstractControl,ValidatorFn } from '@angular/forms';
import { ObjectUtils } from '../../../../util';
import { User } from '../../../../User';
import { Router } from '@angular/router';
declare var $: any;
@Component({
  selector: 'app-manual-entry-delete',
  templateUrl: './manual-entry-delete.component.html',
  styleUrls: ['./manual-entry-delete.component.scss']
})
export class ManualEntryDeleteComponent implements OnInit {
  utilObject: ObjectUtils;
  resultDate: any;
  targetValue: any;

  user=new User();
  constructor(private elRef:ElementRef, private router: Router) { 
    this.utilObject=new ObjectUtils();
  }
  onCancel(event){
		this.router.navigate(['/ics-home/home-page']);
	}
  ngOnInit() {}
  onkeyup(event)
  {
    this.utilObject.onFocus(event.target.value,this.elRef.nativeElement,event.keyCode);
  }
  submitted = false;
  onSubmit() { this.submitted = true; }

}