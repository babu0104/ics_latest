import { Component, OnInit } from '@angular/core';
import { IcsResponse } from '../../../interfaces/manual-entry-response/icsresponse';
import { ApplicationFraud } from '../../../interfaces/manual-entry-response/applicationfraud';
import { CreditCard } from '../../../interfaces/manual-entry-response/creditcard';
import { CreditResponse } from '../../../interfaces/manual-entry-response/creditresponse';
import { BankruptcyAlert } from '../../../interfaces/manual-entry-response/bankruptcyalert';
import { ManualResponse } from '../../../services/manual-entry-response/manualresponse';


@Component({
  selector: 'app-manual-entry-response',
  templateUrl: './manual-entry-response.component.html',
  styleUrls: ['./manual-entry-response.component.scss']
})
export class ManualEntryResponseComponent implements OnInit {
  icsresponses:IcsResponse[];
  appfrauds:ApplicationFraud[];
	creditcards:CreditCard[];
	creditresponses:CreditResponse[];
	bankruptcyalerts: BankruptcyAlert[];
  loading: boolean;
  cols: any[];
  constructor(private manualResponse: ManualResponse) { }

  ngOnInit() {
    this.loading = true;
		/*** Table data1 ***/
		setTimeout(() => {
			this.manualResponse.getICSresponse().then(icsresponses => this.icsresponses = icsresponses);
			this.loading = false;
		

		}, 1000);
			
		this.cols = [
			{field: 'code', header: 'Code'},
			{field: 'description', header: 'Description'}
		];
		/*** Table data1 ***/
		/*** Table data2 ***/
    setTimeout(() => {
			this.manualResponse.getApplicationfraud().then(appfrauds => this.appfrauds = appfrauds);
			this.loading = false;
		

		}, 1000);
			
		this.cols = [
			{field: 'fraudtype', header: 'Fraud Type'},
			{field: 'matchtype', header: 'Match Type'},
      {field: 'accNo', header: 'Account Number'},
			{field: 'reportDate', header: 'Report Date'},
      {field: 'caseno', header: 'Case Number'},
			{field: 'disputeCode', header: 'Fraud Dispute Code'}
		];
		/*** Table data2 ***/

			/*** Table data3 ***/
    setTimeout(() => {
			this.manualResponse.getCreditcard().then(creditcards => this.creditcards = creditcards);
			this.loading = false;
		

		}, 1000);
			
		/*this.cols = [
			{field: 'contact', header: 'contact'},
			{field: 'activity1', header: 'Match Type'},
      {field: 'activity2', header: 'Account Number'},
			{field: 'activity3', header: 'Report Date'},
      {field: 'activity4', header: 'Case Number'},
			{field: 'disputeCode', header: 'Fraud Dispute Code'}
		];*/
		/*** Table data3 ***/
   	/*** Table data4 ***/
		setTimeout(() => {
      this.manualResponse.getCreditresponse().then(creditresponses => this.creditresponses = creditresponses);
      this.loading = false;
    

    }, 1000);
    this.cols = [
      {field: 'details', header: 'Details'},
      {field: 'validationresults', header: 'Validation Results'},
      {field: 'questionabledata', header: 'Questionable Data'}
    ];
		/*** Table data4 ***/

		/***Table data5 ***/
		 setTimeout(() => {
      this.manualResponse.getBankruptcyalert().then(bankruptcyalerts => this.bankruptcyalerts = bankruptcyalerts);
      this.loading = false;
    

    }, 1000);
		this.cols = [
      {field: 'datefiled', header: 'Date Filed'},
      {field: 'currentstatus', header: 'Current Status'},
      {field: 'countnumber', header: 'Count Number'},
      {field: 'chaptertype', header: 'Chapter Type'},
      {field: 'namefiled', header: 'Name Filed'},
      {field: 'debtindicator', header: 'Debt Indicator'},
      {field: 'bankruptcydisputecode', header: 'Bankruptcy dispute code'},
    ];


				/***Table data5 ***/


  }

}
