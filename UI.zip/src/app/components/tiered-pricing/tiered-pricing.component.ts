import { Component, OnInit, ElementRef,Directive, forwardRef, Attribute,OnChanges, SimpleChanges,Input } from '@angular/core';
import { NG_VALIDATORS,Validator,Validators,AbstractControl,ValidatorFn } from '@angular/forms';
import { ObjectUtils } from '../../util';
import { Router } from '@angular/router';


@Component({
  selector: 'app-tiered-pricing',
  templateUrl: './tiered-pricing.component.html',
  styleUrls: ['./tiered-pricing.component.scss'],
  providers: []
})
export class TieredPricingComponent implements OnInit {
  Data: any[];
  cols: any[]; 
  constructor() {
    
  }

  ngOnInit() {
    
    this.Data = [
    { "low": "1", "high": "1000", "price1": "", "price2": "", "price3": "", "price4": "", "price5": "", "price6": "" },
    { "low": "1", "high": "1000", "price1": "", "price2": "", "price3": "", "price4": "", "price5": "", "price6": "" },
    { "low": "1", "high": "1000", "price1": "", "price2": "", "price3": "", "price4": "", "price5": "", "price6": "" },
    { "low": "1", "high": "1000", "price1": "", "price2": "", "price3": "", "price4": "", "price5": "", "price6": "" },
    { "low": "1", "high": "1000", "price1": "", "price2": "", "price3": "", "price4": "", "price5": "", "price6": "" },
    { "low": "1", "high": "1000", "price1": "", "price2": "", "price3": "", "price4": "", "price5": "", "price6": "" },
    ];
    this.cols = [
    { field: 'low', header: 'Low' },
    { field: 'high', header: 'High' },
    { field: 'price1', header: 'Price' },
    { field: 'price2', header: 'Price' },
    { field: 'price3', header: 'Price' },
    { field: 'price4', header: 'Price' },
    { field: 'price5', header: 'Price' },
    { field: 'price6', header: 'Price' },
    ]; 
    
  }



}

