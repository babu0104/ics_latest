import { Component, OnInit, ElementRef } from '@angular/core';
import { ObjectUtils } from '../../util'

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss']
})
export class ReportsComponent implements OnInit {
  utilObject: ObjectUtils;
  resultDate: any;
  targetValue: any;
  startDate: string;
  endDate: string;
  currentDate: any;
  currentMonth: any;
  currentYear: any;
  today: any;
  selectedReportType: string = "";

  constructor(private elRef: ElementRef) {
    this.utilObject = new ObjectUtils();
  }

  ngOnInit() {
    // setting current date as default value for start and end date
    this.today = new Date();

    this.currentDate = this.today.getDate();
    this.currentMonth = this.today.getMonth() + 1;
    this.currentYear = this.today.getFullYear();

    this.startDate = this.currentDate + '/' + this.currentMonth + '/' + this.currentYear;
    this.endDate = this.currentDate + '/' + this.currentMonth + '/' + this.currentYear;
  }

  selectReportType(reportType: string) {
    this.selectedReportType = reportType;

    // start date will be a month earlier for report type "ics-billing-reconciliation-report"
    if (this.selectedReportType === "ics-billing-reconciliation-report") {
      this.currentMonth = this.today.getMonth();
      this.startDate = this.currentDate + '/' + this.currentMonth + '/' + this.currentYear;
    } else {
      this.currentMonth = this.today.getMonth() + 1;
      this.startDate = this.currentDate + '/' + this.currentMonth + '/' + this.currentYear;
    }
  }

  onkeyup(event) {
    this.utilObject.onFocus(event.target.value, this.elRef.nativeElement, event.keyCode);
  }
}
