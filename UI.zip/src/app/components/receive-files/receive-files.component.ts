import { Component, OnInit } from '@angular/core';
import { User } from '../../interfaces/user';
import { UserService } from '../../services/userservices';
import { ConfirmationService, GrowlModule, Message } from 'primeng/primeng';
import { Router } from '@angular/router';
declare var $: any;
@Component({
  selector: 'app-receive-files',
  templateUrl: './receive-files.component.html',
  styleUrls: ['./receive-files.component.scss'],
  providers: [ConfirmationService]
})

export class ReceiveFilesComponent implements OnInit {
  title = 'app';
  loading: boolean;
  users: User[];
  cols: any[];
  display: boolean = false;
  newuser: boolean = false;
  delRow: any;
  msgs: Message[] = [];

  constructor(private userService: UserService, private confirmationService: ConfirmationService, private router: Router) { }

  showDialog() {
    this.display = true;
  } 
  newuserDialog() {
    this.newuser = true;
  }
  onCancel(event){
		this.router.navigate(['/ics-home/home-page']);
	}


  ngOnInit() {
    this.loading = true;
    // setTimeout(() => {
    //   this.userService.getUsers().subscribe(users => this.users = users);
    //   console.log(this.users);
    //   this.loading = false;
    // }, 1000);

    this.cols = [
      { field: 'name', header: 'Name' },
      { field: 'userID', header: 'userID' },
      { field: 'role', header: 'role' },
      { field: 'service', header: 'service' }
    ];
  }

  download(row) {
    this.confirmationService.confirm({
      message: 'Do you want to download this record?',
      header: 'Download Confirmation',
      icon: 'fa fa-download',
      accept: () => { },
      reject: () => { }
    });
  }

  delete(row) {
    this.confirmationService.confirm({
      message: 'Do you want to delete this record?',
      header: 'Delete Confirmation',
      icon: 'fa fa-trash',
      accept: () => {
        this.users.splice(this.users.indexOf(row), 1);
        this.users = this.users.slice();
      },
      reject: () => { }
    });
  }
}
