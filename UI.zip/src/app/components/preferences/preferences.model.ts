export class PreferencesModel{
       public userbid:number;
       public defaultService: string;
       public defaultBin: string;
       public submissionType:string;
       public selectMSO:string;
       public msodefaultBin:string;
       public msoBid:string;
       public msoBin:string;
       public purgeBid:number;
       public purgedefaultBin:string;
       public purgeBin:string;
       public purgedays:number;
       public optradio:number;
       public dateVal:Date;
       
       constructor(){}
}
/*interface MSO {
   label:string;
   value:string;
}*/