import { Component, OnInit,HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { UserLoginService } from '../../services/userLoginService';
import { AuthenticationService, Auth_UserService } from '../../_services/index';
import { UserService } from '../../services/userservices';
import { User } from '../../_models/user';
import { Role } from '../../_models/Role';
import * as _ from 'underscore';
import { PlatformLocation } from '@angular/common';
import { HeaderComponent } from '../../shared/header/header.component';
@Component({
  selector: 'app-ics-home',
  templateUrl: './ics-home.component.html',
  styleUrls: ['./ics-home.component.scss'],
  providers: [HeaderComponent],
})
export class IcsHomeComponent implements OnInit {
  userModel = new User();
  roleModel = new Role();
  map: any;
  public token: string;

  public showHome: boolean;
  public showSubmitData: boolean;
  public showManualentry: boolean;
  public showFileupload: boolean;
  public showViewRecords: boolean;
  public showReceiveFiles: boolean;
  public showAdmin: boolean;
  public showUserAdmin: boolean;
  public showPreferences: boolean;
  public showReports: boolean;
  loginCancelled: boolean = true;


  constructor(private router: Router,
  private user_Service: Auth_UserService, 
  private authService: AuthenticationService,
  private loggedInUserService: UserService,
  private location: PlatformLocation,
  private userLoginService: UserLoginService,
  private headerComponent : HeaderComponent) {  
    this.headerComponent.ngAfterViewInit(); //trigger second time to make sure role in header are updated    
  }
  sub: any;
  role: string;
  roleId: string;

  ngOnInit() {
    let _self = this;
    let result = [];
    let authorisedUserModel = this.user_Service.getLoggedInUserDetails();
    this.headerComponent.ngAfterViewInit(); //trigger second time to make sure role in header are updated
    if(_.isObject(authorisedUserModel)){
      if(!_.isUndefined(authorisedUserModel)){
        _self.role = authorisedUserModel.role;
        _self.setNavigation(_self.role);
      } else{
        console.log("no response");
      }
    }
    
  }



  setNavigation = (role) => {

    switch (role) {
      case "IA": {
        // console.log("issuer Admin");
        break;
      }
      case "G":
      case "P":
      case "VU": {
        this.showHome = true;
        this.showSubmitData = true;
        this.showManualentry = true;
        this.showFileupload = true;
        this.showViewRecords = true;
        this.showReceiveFiles = true;
        this.showAdmin = true;
        this.showUserAdmin = true;
        this.showPreferences = true;
        this.showReports = true;
        break;
      }
      case "VM":
      case "VA": {
        this.showHome = false;
        this.showSubmitData = false;
        this.showManualentry = false;
        this.showFileupload = false;
        this.showViewRecords = false;
        this.showReceiveFiles = false;
        this.showAdmin = true;
        this.showUserAdmin = true;
        this.showPreferences = true;
        this.showReports = false;
        break;
      }
      default: {
        console.log("Invalid role received from login service as follow ->" + role);
        break;
      }
    }
  }

}
