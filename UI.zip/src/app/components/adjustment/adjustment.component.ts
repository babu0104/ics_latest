import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-adjustment',
  templateUrl: './adjustment.component.html',
  styleUrls: ['./adjustment.component.scss']
})
export class AdjustmentComponent implements OnInit {

  loading: boolean;
  Data: any[];
  cols: any[];

  constructor() { }

  ngOnInit() {
    this.Data = [
      { "Quantity": "1", "Amount": "1000", "TotalAmount": "1000", "Date": "12/12/2017" },
      { "Quantity": "1", "Amount": "1000", "TotalAmount": "1000", "Date": "12/12/2017" },
      { "Quantity": "1", "Amount": "1000", "TotalAmount": "1000", "Date": "12/12/2017" },
      { "Quantity": "1", "Amount": "1000", "TotalAmount": "1000", "Date": "12/12/2017" },
      { "Quantity": "1", "Amount": "1000", "TotalAmount": "1000", "Date": "12/12/2017" },
    ];
    this.cols = [
      { field: 'Quantity', header: 'Quantity' },
      { field: 'Amount', header: 'Amount' },
      { field: 'TotalAmount', header: 'Total Amount' },
      { field: 'Date', header: 'Date' }
    ];
  }


}
