import { Component, Directive, forwardRef, Attribute, OnChanges, SimpleChanges, Input, OnInit, TemplateRef } from '@angular/core';
import { NG_VALIDATORS, Validator, Validators, AbstractControl, ValidatorFn } from '@angular/forms';
import { Headers, Response, RequestOptions, URLSearchParams, Http } from '@angular/http';
import { Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { templateOptionProvider } from '../../services/templateoptionprovider.serivce';
import { SecurityImage } from '../../interfaces/user-admin-images';
import { UserAdmin } from '../../interfaces/user-admin';
import { UserService } from '../../services/userservices';
import { CreateUser } from '../../create-user';
import { userRoleService } from '../../services/user-roles-services';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import * as _ from 'underscore';

import { GrowlModule } from 'primeng/primeng';
import { Message } from 'primeng/components/common/api';
import { MessageService } from 'primeng/components/common/messageservice';
import { SubmissionType } from '../../interfaces/admin_preferences/submissiontype';
import { CreateUserService } from '../../_services/createuser.service';
import * as $ from 'jquery';
import { forEach } from '@angular/router/src/utils/collection';
import { environment } from '../../../environments/environment';

@Component({
  moduleId: module.id,
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.scss'],
  providers: [userRoleService, MessageService]
})

export class EditUserComponent implements OnInit {

  createuser = new CreateUser();
  users: UserAdmin[];
  msgs: Message[] = [];
  images: any;
  cols: any[];
  bidvalues = [];

  modalRef: BsModalRef;
  securityImageUrl: any;
  selectedImageUrl: any;

  showUserAdmin: boolean = false;
  showEditUser: boolean = true;
  loading: boolean;
  currentDate: string;

  icsFlag: boolean = false;
  pcsFlag: boolean = false;
  status: boolean = false;

  userRoles: string[];
  roles: any[];
  selectedRole: {};

  bids: any[];
  submissiontypes: any[];
  selectedBids: any[];
  selectedBins: any[];
  selectedSubmitTypes: any[];
  defaultRoleDesc: string;
  loggedInUserRoleId: string;
  showBins: boolean;
  showSubmission: boolean;
  allowedBins = [];
  filteredBids: any[];
  bin: string;
  binList = [];
  inArr = [];
  subTypes = [];
  showSubm: boolean;
  bidNode = {};
  binNode = {};
  subSystemNode = {};
  subTyeNode = {};
  submissionTypePkNode = {};
  createuserNode = {};
  subNode = {};
  bidval: string;

  bidBinSubmissionArray = [];

  selectedValues:string[];
  checkedValues:string[];

  checkedBins=[];

  submissionTypeAll=[];
  
  private api: string;
  securityImageName:string;
  @Input() userDetail: any;

  constructor(
    private router: Router,
    private modalService: BsModalService,
    private userService: UserService,
    private userRoleService: userRoleService,
    private http: Http,
    private messageService: MessageService,
    private createUserService: CreateUserService
  ) { 
    this.images = [
      { imgname: '1' }, { imgname: '3' }, { imgname: '4' }, { imgname: '5' }, { imgname: '6' },
      { imgname: '7' }, { imgname: '8' }, { imgname: '9' }, { imgname: '10' }, { imgname: '11' },
      { imgname: '12' }, { imgname: '13' }, { imgname: '14' }, { imgname: '15' },
      { imgname: '16' }, { imgname: '17' }, { imgname: '18' }, { imgname: '19' }, { imgname: '20' },
      { imgname: '21' }, { imgname: '22' }, { imgname: '23' }, { imgname: '24' }, { imgname: '25' },
      { imgname: '26' }, { imgname: '27' }, { imgname: '28' }, { imgname: '29' }
    ];
    this.api = environment.visaAdminUrl;
      $(document).on("click", ".toggle", function (e) {
        //alert('hi');
        e.preventDefault();
      
        var $this = $(this);
      
        if ($this.next().hasClass('show')) {
            $this.next().removeClass('show');
            //$this.next().slideUp(350);
        } else {
            $this.parent().parent().find('li .inner').removeClass('show');
            //$this.parent().parent().find('li .inner').slideUp(350);
            $this.next().toggleClass('show');
            //$this.next().slideToggle(350);
        }
        e.stopImmediatePropagation();
    });
  }

  ngOnInit() {
    
    $(document).on("click", ".child", function () {
      let $parent;
      $parent = $(this).parents("li").find('.parent');
      if ($(this).is(":checked")){
        $parent.prop("checked", true);
      } 
      else {
        var len = $(this).parents("li").find(".child:checked").length;
        $parent.prop("checked", len > 0);
      }
    });
    $(document).on("click", ".checkmark", function (event) {
      $(this).each(function(){
        if ($(this).prev('input.parent').is(':checked'))
        {
          $(this).prev().prop("checked", false);
          $(this).closest('li').find('input:checkbox').prop("checked", false);
        }
        else{
          $(this).prev('input.parent').prop("checked", true);
        }
        
        event.stopImmediatePropagation();
      });
    });
    this.loading = true;
    this.createuser = this.userDetail[0];

    this.icsFlag = (this.createuser.ics === "1") ? true : false;
    this.pcsFlag = (this.createuser.pcs === "1") ? true : false;
    this.status = (this.createuser.status === "1") ? true : false;

    //let roleId = this.createuser.roleDto.roleId;

    //this.loggedInUserRoleId= this.userService.getLoggedInUserRoleId();
    this.getuserrole();


    this.createuser.defaultRoleDesc = this.createuser.roleDto.roleDesc;
    if(this.createuser.userBidBinSubmissionMasterDto !=undefined && this.createuser.userBidBinSubmissionMasterDto !==null)
    {
      this.bidval = this.createuser.userBidBinSubmissionMasterDto.bid;
      this.binList=this.createuser.userBidBinSubmissionMasterDto.binSubmissiontypeDto;
      if(this.bidval!=undefined && this.bidval!=null)
      {
        this.bidNode = this.createUserService.createBidTree(this.bidval, null);
      }
    }
    

    setTimeout(() => {
      //this.userRoleService.getuserrbid().subscribe(res => this.bids = res);
      //this.userRoleService.getsubmissiontypes().subscribe(res => this.submissiontypes = res);
      this.loading = false;
    }, 1000);
    //this.userRoleService.getuserrole().subscribe(res => this.roles = res);

    this.cols = [
      { field: 'bidDesc', header: 'BIDs' },
      { field: 'subTypeDesc', header: 'Submit Type' }
    ];
  }
  getuserrole() {
    this.loggedInUserRoleId = "VA";
    let userAction = "update";
    this.userService.getUserRoleById(this.loggedInUserRoleId, userAction).subscribe(userRoles => {
      this.userRoles = userRoles;
      this.roles = this.userRoles;
    });
  }
  filterBins(event) {
    let getbid = event.query;
    setTimeout(() => {
      this.userRoleService.getSubmission(getbid).subscribe(res => {
        this.bidvalues = res;
      });

      this.loading = false;
    }, 1000);

    this.filteredBids = [];
    for (let i = 0; i < this.bidvalues.length; i++) {
      let bidvalue = this.bidvalues[i].bidCode;
      if (bidvalue.toLowerCase().indexOf(event.query.toLowerCase()) == 0) {
        this.filteredBids.push(bidvalue);
      }
    }
  }

  backToUserAdmin() {
    this.showUserAdmin = !this.showUserAdmin;
    this.showEditUser = !this.showEditUser;
  }

  selectImage(image: any) {
    this.selectedImageUrl.setAttribute('src', image.src);
  }

  setImage() {
    this.securityImageUrl.setAttribute('src', this.selectedImageUrl.getAttribute('src'));
    this.securityImageName = this.securityImageUrl.getAttribute('src').substring(this.securityImageUrl.getAttribute('src').lastIndexOf('/')+1);
    this.closeModal();
  }

  public openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);

    this.securityImageUrl = document.getElementById('security-image');
    this.selectedImageUrl = document.getElementById('selected-image');

    this.selectedImageUrl.setAttribute('src', this.securityImageUrl.getAttribute('src'));
  }

  public closeModal() {
    this.modalRef.hide();
  }

  // form submit
  submitted = false; //form not submited : default
  data: string; //this variable contains our data

  //Show data after form submit and set submitted to true
  onSubmit(data) {
    this.submitted = true;
    this.updateUser(data);
    // appending the selected bids/bins/submit types to data json, to be send to the server
    // if (!_.isUndefined(this.selectedBids) && this.selectedBids.length != 0) {
    //   data['bid'] = this.selectedBids;
    // }
    // if (!_.isUndefined(this.selectedBins) && this.selectedBins.length != 0) {
    //   data['bin'] = this.selectedBins;
    // }
    // if (!_.isUndefined(this.selectedSubmitTypes) && this.selectedSubmitTypes.length != 0) {
    //   data['submitType'] = this.selectedSubmitTypes;
    // }

    // this.selectedRole = this.roles.filter(function (node) {
    //   return node.roleDesc == data.roleDesc;
    // });

    // delete data['roleDesc'];
    // delete data['confirmPassword'];

    // data['roleDto'] = Object.assign({}, this.selectedRole[0]);
    // data['ics'] = data.ics ? "1" : "0";
    // data['pcs'] = data.pcs ? "1" : "0";
    // data['status'] = data.status ? "1" : "0";
    // // data['lastModifiedDate'] = this.currentDate;
    // //data['lastModifiedDate'] = this.createuser.lastModifiedDate;
    // // data['usercreationDate'] = this.createuser.usercreationDate;
    // data['secImg'] = "1"; // assing actual value instead of "1"

    // let headers = new Headers({ 'Content-Type': 'application/json' });
    // let options = new RequestOptions({ headers: headers });

    // this.http.post(this.api+'/userAdmin/user/updateUser', JSON.stringify(data), options).subscribe(
    //   data => {
    //     this.showSuccess();
    //   },
    //   err => {
    //     this.showError();
    //   }
    // );
  }
  updateUser(param){
    this.bidBinSubmissionArray=[];
    this.selectedRole = this.roles.filter(function (node) {
        return node.roleDesc == param.roleDesc;
    });
    let _self = this;
    let binNodes;
    let finalArray
    $('input.parent:checked').each(function() {
      let checkedbin=$(this).val();
      binNodes=_self.formbin(checkedbin);
      $(this).closest('li').find('input.child:checked').each(function(){
        let str = $(this).val();
        let str_array = str.split('-');

        let subtypeCode = str_array[0];
        let subtypeDesc = str_array[1];
        let subTypeSys = str_array[2];

        finalArray=_self.formSubType(subtypeCode, subTypeSys, subtypeDesc,binNodes);
       
      });
    });
    this.createuserNode = this.createUserService.createUserNode(param, finalArray,this.selectedRole[0],this.securityImageName);
    console.log(JSON.stringify(this.createuserNode));
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });

    this.http.post(this.api+'/user/updateUser', JSON.stringify(this.createuserNode), options).subscribe(
      data => {
        this.showSuccess();
      },
      err => {
        this.showError();
      }
    );
  }

  showSuccess() {
    this.msgs = [];
    this.msgs.push({ severity: 'success', summary: 'Success!', detail: 'User updation successfull' });
  }

  showError() {
    this.msgs = [];
    this.msgs.push({ severity: 'error', summary: 'Error!', detail: 'User updation failed' });
  }

  resetPassword(event) {
    // make an api call for password reset
  }
  onRowSelect(event: any) {
    let _self = this;
    _self.showBins = true;
    _self.showSubmission = false;
    let bId = event;
    let binListArray = _self.getBins(bId);
    if (_.isArray(binListArray) && !_.isUndefined(binListArray)) {
    } else {
      // alert("Error Occured while fetching Bin");
    }

  }
  
  getBins(bid) {
    var _self = this;
    let selectedBid = (_.isUndefined(bid) || _.isNull(bid)) ? null : bid;
    _self.bidNode = this.createUserService.createBidTree(selectedBid, null);

    _self.userRoleService
      .getBinList(selectedBid)
      .subscribe(res => {
        this.binList = res;
      });
  }
  formbin(bin) {
    let selectedBin = (_.isUndefined(bin) || _.isNull(bin)) ? null : bin;
    this.binNode = this.createUserService.createBinTree(selectedBin, null);
    return this.binNode;
}
  formSubType(subtypeCode, subTypeSys, subtypeDesc, currentBinNode) {
    let submissionCode = (_.isUndefined(subtypeCode) || _.isNull(subtypeCode)) ? null : subtypeCode;
    let submissionSystem = (_.isUndefined(subTypeSys) || _.isNull(subTypeSys)) ? null : subTypeSys;
    this.subSystemNode = this.createUserService.createSubSystemTree(submissionCode, submissionSystem);
    this.subTyeNode = this.createUserService.createSubType(this.subSystemNode, subtypeDesc);
    this.submissionTypePkNode = this.createUserService.createfinalTree(this.bidNode, currentBinNode, this.subTyeNode);
    this.subNode = { "userBidBinSubmissionTypePk": this.submissionTypePkNode };
    this.bidBinSubmissionArray.push(this.subNode);
    return this.bidBinSubmissionArray;
  }

  onRowUnSelect(event: any) {
    this.subTypes = [];
    this.inArr = [];
    this.showSubmission = false;
    this.showBins = false;
    this.showSubm = false;
    this.allowedBins = [];
  }

  private sortByWordLength = (a: any) => {
    return a.name.length;
  }

}