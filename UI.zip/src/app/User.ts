export class User {
    public userID: string;
    public newPassword: string;
    public first: string;
    public middle: string;
    public last: string;
    public ssnNumber: number;
    public bDate: Date;
    public addr1: any;
    public addr2: any;
    public city: string;
    public state: string;
    public zip: number;
    public phonenumber1: number;
    public email: string;
    public ipaddress: number;
    public caseNumber: number;
    public fraudType: string;
    public accno: number;
    public comments: any;
    public entryDate: Date;
    public originalLocatorNumber: number;
    public originalBin: number;
    public securityPhrase: string;
    constructor() { }
   }
