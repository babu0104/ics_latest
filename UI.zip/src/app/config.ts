import {Injectable} from '@angular/core';
import * as _ from 'underscore'; 

@Injectable()
export class config {
    /**before login**/
    public readonly DEFAULTSECIMG = "1.jpg";
    public readonly DEFAULTSECPHRASE = "Hello World!";
    

}