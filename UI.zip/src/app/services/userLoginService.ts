import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class UserLoginService {
    private loggedIn = new Subject<boolean>();
    private loginCancelled = new Subject<boolean>();
    isHovered: boolean = false;

    // Observable string streams
    loggedIn$ = this.loggedIn.asObservable();
    loginCancelled$ = this.loginCancelled.asObservable();

    // Service message commands
    enabledLoggedIn(loggedInStatus: boolean) {
        this.loggedIn.next(loggedInStatus);
    }

    cancelLogin(goToHome: boolean) {
        this.loginCancelled.next(goToHome);
    }

    //Has to integrate with actual service
    getStatus() {
        this.isHovered = true;
        //servcie goes here
        return this.isHovered;
    }
}