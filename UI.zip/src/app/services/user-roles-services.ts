import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers, URLSearchParams } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { SubmissionType } from '../interfaces/admin_preferences/submissiontype';
import * as _ from "underscore";
import { environment } from '../../environments/environment';

@Injectable()
export class userRoleService {
    private api: string;
    constructor(private http: Http, private httpclient: HttpClient) { 
        this.api = environment.visaAdminUrl;
    }

    getuserrole(roleId,userAction): Observable<any[]> {
        // let urlParams = new URLSearchParams();
        // urlParams.set('action', 'update');
        let actionValue = userAction;
        let data = { 'roleId': roleId };
        return this.http.post(this.api+'/user/rolesbyId?action=' + actionValue, data)
            .map(res => res.json())
    }

    /*getSubmission():Observable<any[]> {
        //debugger;
        return this.http.get('../assets/data/submissionmap.json')
        .map((res) =>{
            let data=res.json();
           
          return data;
        }); 
    }*/
    getSubmission(getbid:string): Observable<any[]>{
        //debugger;
        let biddata = { 'bidCode': getbid };
        return this.http.post(this.api+'/user/bid/bidCode', biddata)
            .map((res) =>{ 
                let data=res.json();
                return data;
            });
    }

    // getuserrbid(): Observable<any[]> {
    //     let data = { 'userId': 'meghana17' };
    //     return this.http.post('http://10.129.155.104:8080/user/bid/uderId', data)
    //         .map(res => res.json())
    // }

    // getuserrbin(): Observable<any[]> {
    //     return this.http.get('http://10.129.155.104:8080/user/bin')
    //         .map(res => res.json())
    // }

    // getsubmissiontypes(): Observable<any[]> {
    //     return this.http.get('http://10.129.155.104:8080/user/submissiontypes')
    //         .map(res => res.json())
    // }

    getAllImages(): Observable<any[]> {
        return this.http.get(this.api+'/user/getAllImages')
            .map(res => res.json())
    }
    /*fetchSubmission(bin:number): Observable<any>
    {
        debugger;
        return this.http.get('../assets/data/submissionmap.json')
        .map((res) =>{
            let data=res.json();
            const result = [];
            Object.keys(data.submissionMap[0].BINS).forEach( key => {
                if(data.submissionMap[0].BINS[key].bin === bin){
                    result.push(data.submissionMap[0].BINS[key].submission_type);
                }
            });
            return result;
        }); 
    }*/
    getBinList(bidArray): Observable<any> {
        let binList, binFullArray, filteredArray = [];
        let bid = { 'bid': bidArray };

        //debugger;
        /*return this.http.post('/api/user/retriveUserBidBinStypeData', bid)
        .map((res) =>{
            data = res.json();
            data.submissionMap.forEach(function(value , idx) {
                if(value.BID===bidArray)
                { 
                    let binFullArray = value.BINS;
                    for( let i = 0 ; i < binFullArray.length; i++ ){
                        filteredArray.push(binFullArray[i]);
                    }
                }
            });
            return filteredArray;
        });*/
        let url = this.api+"/user/retriveUserBidBinStypeData";
        let body = {
            "bid": bidArray
        };
        let result;
        return this.http.post(url, body).map((res) => {

            result = res.json();
            if (result.bid === bidArray) {

                let binFullArray = result.binSubmissiontypeDto;
                for (let i = 0; i < binFullArray.length; i++) {
                    filteredArray.push(binFullArray[i]);
                    console.log(filteredArray);
                }
            }
            return filteredArray;
        },
            err => {
                console.log(err);
            });
    }
    /*getTypeList( binListArray ) : Observable < any > {
        let result = [];
        let data;
        let inputArray = binListArray;

        return this.http.get('../assets/data/submissionmap.json')
        .map((res) =>{ 
            data = res.json();
            data.submissionMap.forEach(function(value , idx) {
                let binFullArray = value.BINS;
                for( let i = 0 ; i < binFullArray.length; i++ ){
                    debugger;
                    _.each(inputArray , function( v , idx ){
                        if(binFullArray[i].bin === v ){
                           result.push(binFullArray[i]);
                        }
                    });
                    
                }
            });  
            //inputArray=[];
            return result;
        })
    }*/


}

