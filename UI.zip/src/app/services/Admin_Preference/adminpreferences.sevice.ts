import { Http, Response } from '@angular/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs';
import { UserPreference } from '../../interfaces/admin_preferences/userpreference';

@Injectable()
export class AdminPreferencesService {
    user_id:number;
    constructor(private http: Http) { }

    /*bindPreferences(updateObj:any)
    {
     console.log(updateObj);
    }*/
    public getUsers(){
        //this.user_id=177;
        
        return this.http.get('assets/data/userpreferences/userpreference.json').map((res:Response) => res.json());
    }
}