export class AuthState {
    static isLoggedIn: boolean;
}