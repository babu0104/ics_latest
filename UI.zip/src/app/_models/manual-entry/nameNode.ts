export class Name {
    firstName: string;
    middleName?: any;
    lastName: string;

    constructor() { }
}