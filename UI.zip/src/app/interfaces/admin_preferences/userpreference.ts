export interface UserPreference {
    user_bid;
    user_dservice;
    user_dbin;
    user_type;
    user_mso;
    mso_bid;
    mso_dbin;
    mso_bin;
    mso_details;
    purge_bid;
    purge_dbin;
    purge_bin;
    purge_days;
    purge_selected_option;
    selected_date;
}
