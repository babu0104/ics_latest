export interface UserAdmin {
	name;
	userID;
	role;
	service,
	created,
	modified,
	last_login,
	status;
}	