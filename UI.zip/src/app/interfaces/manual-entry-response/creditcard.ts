export interface CreditCard {
    contact;
    activity1;
    activity2;
    activity3;
    activity4;
    disputeCode;
}