export interface IcsResponse {
    code;
    description;
}
