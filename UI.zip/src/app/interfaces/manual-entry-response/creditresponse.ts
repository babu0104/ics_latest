export interface CreditResponse {
    details;
    validationresults;
    questionabledata;
}
