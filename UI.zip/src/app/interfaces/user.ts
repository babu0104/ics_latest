export interface User {
	firstName;
	lastName;
	userId;
	userRole;
	roleDesc;
	service,
	usercreationDate,
	lastModifiedDate,
	lastLoginDate,
	status;
	email;
	phone;
	secPhase;
	ipAddress;
	ics;
	pcs;
}