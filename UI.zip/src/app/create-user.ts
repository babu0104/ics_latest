export class CreateUser {
    public userId: string;
    public firstName: string;
    public lastName: string;
    public phone: string;
    public email: string;
    public ics: string;
    public pcs: string;
    public secPhase: string;
    public secImg: string;
    public ipAddress: string;
    
    public roleDto: {
        roleId: string;
        roleDesc: string;
        hierarchyValue: string;
    };
    public userBidBinSubmissionMasterDto:{
        bid: string;
        binSubmissiontypeDto:Array<any>;
    }
   
    public defaultRoleDesc:string;
    
    public status: string;
    public lastModifiedDate: string;
    public lastLoginDate: string;
    public usercreationDate: string;


    public selected1: number;
    public selected2: number;
    public selected3: number;
    public bidCode: number;
    public bidDesc: string;
    public subTypeCode: number;
    public subTypeSys: string;
    public subTypeDesc: string;
    constructor() { }
}